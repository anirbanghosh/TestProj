﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DycomSafteyViewDAL
{
   public class SqlDataFactory:IDisposable
    {

        
        protected SqlConnection _connection = null;
        protected SqlTransaction _transaction = null;
        private bool _isInTransaction = false;
        protected int _cmdTimeOut = 30;
        private BasePage objBase= new BasePage();
        protected string _connectionString = "Server=10.1.30.96;Database=EDM;Uid=nr0016;Pwd=nr0016@123;";
        //For Local Access //"Server=70.38.37.83;Database=DycomSafetyView;Uid=Dycom_DBuser;Pwd=dycom$afetyV;";//string.Empty;
        #region Constructors

        /// <summary>
        /// Default Constructor. Not Recommended
        /// </summary>
        public SqlDataFactory() { }

        /// <summary>
        /// Constructor for SQLDataFactory
        /// </summary>
        /// <param name="sConnectionString">Valid Connectionstring to the Database</param>
        public SqlDataFactory(string sConnectionString)
        {
            this.ConnectionString = sConnectionString;
            this.Connection = new SqlConnection(this.ConnectionString);
            this.ConnectDB();
        }

        /// <summary>
        /// Constructor to SqlDataFactory. 
        /// </summary>
        /// <param name="sConnectionString">Valid Database Connectionstring</param>
        /// <param name="iCommandTimeOut">Server command Timeout interval in seconds</param>
        public SqlDataFactory(string sConnectionString, int iCommandTimeOut)
        {
            this.ConnectionString = sConnectionString;
            this.Connection = new SqlConnection(this.ConnectionString);
            this.CommandTimeOut = iCommandTimeOut;
            this.ConnectDB();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets/Sets Connectionstring initialized.
        /// </summary>
        public string ConnectionString
        {
            get { return _connectionString; }
            set { _connectionString = value; }
        }

        /// <summary>
        /// Gets/Sets Connection object
        /// </summary>
        public SqlConnection Connection
        {
            get { return _connection; }
            set
            {
                if (value != null || _connection == null)
                    _connection = value;
                else if (value == null && _connection != null)
                {
                    _connection.Dispose();
                    _connection = null;
                }
            }
        }

        public SqlTransaction Transaction
        {
            get { return _transaction; }
            set { _transaction = value; }
        }

        public bool IsInTransaction
        {
            get { return _isInTransaction; }
            set { _isInTransaction = value; }
        }

        /// <summary>
        /// Timeout seed for command. Default is 30 sec.
        /// </summary>
        public int CommandTimeOut
        {
            get { return _cmdTimeOut; }
            set { _cmdTimeOut = value; }
        }

        #endregion

        #region Connection Functions

        /// <summary>
        /// Connect to Database
        /// </summary>
        public void ConnectDB()
        {
            this.Connection = this.Connection ?? new SqlConnection(this.ConnectionString);

            if (this.Connection.State != ConnectionState.Open)
            {
                this.Connection.ConnectionString = this.ConnectionString;
                this.Connection.Open();
            }
        }

        /// <summary>
        /// Disconnect from the Database
        /// </summary>
        public void DisconnectDB()
        {
            if (!this.IsInTransaction)
            {
                if (this.Connection != null)
                    if (this.Connection.State != ConnectionState.Closed)
                        this.Connection.Close();
            }
        }

        #endregion

        #region Transaction Functions

        public SqlTransaction BeginTransaction()
        {
            if (!this.IsInTransaction)
            {
                this.IsInTransaction = true;
                this.ConnectDB();
                this.Transaction = this.Connection.BeginTransaction();
            }
            return this.Transaction;
        }

        public void CommitTransaction()
        {
            if (this.IsInTransaction)
            {
                this.Transaction.Commit();
                this.IsInTransaction = false;
                this.DisconnectDB();
            }
        }

        public void RollbackTransaction()
        {
            if (this.IsInTransaction)
            {
                this.Transaction.Rollback();
                this.IsInTransaction = false;
                this.DisconnectDB();
            }
        }

        #endregion

        #region GetDataSet Functions

        /// <summary>
        /// Returns DataSet from a Sql Command. It runs the SQL in CommandType.Text
        /// </summary>
        /// <param name="sql">Complete Command Text</param>
        /// <returns>Resultant Output of the Command. Throws Exception</returns>
        public DataSet GetDataSet(string sql)
        {
            return this.GetDataSet(sql, false, null);
        }

        /// <summary>
        /// Returns DataSet from a Stored Procedure. It runs the SQL in CommandType.StoredProcedure
        /// </summary>
        /// <param name="spName">Name of the Stored procedure</param>
        /// <param name="parameters">Parameter List</param>
        /// <returns>returns the Dataset</returns>
        public DataSet GetDataSet(string spName, params SqlParameter[] parameters)
        {
            return this.GetDataSet(spName, true, parameters);
        }

        /// <summary>
        /// Runs the Sql text and Returns the Output as Dataset
        /// </summary>
        /// <param name="sql">It may be the complete SQL Statement or name of a Stored Proc</param>
        /// <param name="isStoredProc">Is it a Storedprocedure</param>
        /// <param name="parameters">Parameters</param>
        /// <returns>DataSet result</returns>
        public DataSet GetDataSet(string sql, bool isStoredProc, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                return this.GetDataSet(cmd, isStoredProc, parameters);
            }
        }

        /// <summary>
        /// Executes SQL Command
        /// </summary>
        /// <param name="cmd">Command Object</param>
        /// <param name="isStoredProc">If Command Text is a Stored Proc</param>
        /// <param name="parameters">Parameters</param>
        /// <returns>Resultant DataSet</returns>
        public DataSet GetDataSet(SqlCommand cmd, bool isStoredProc, params SqlParameter[] parameters)
        {
            this.ConnectDB();
            DataSet ds = null;
            try
            {
                cmd = this.GetCommandWithParams(cmd, isStoredProc, parameters);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                ds = ds ?? new DataSet();
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                this.DisconnectDB();
            }
            return ds;
        }

        #endregion

        #region GetDataTable Functions

        public DataTable GetDataTableBySQL(string sql)
        {
            DataTable dt = null;
            try
            {
                SqlDataAdapter adap = new SqlDataAdapter(sql, this.Connection);
                dt = new DataTable();
                adap.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }


        /// <summary>
        /// Returns Datatable result from SQL
        /// </summary>
        /// <param name="sql">Valid Select Statement, Must be a Normal SQL</param>
        /// <returns></returns>
        public DataTable GetDataTable(string sql)
        {
            return this.GetDataTable(sql, false);
        }

        /// <summary>
        /// Returns Resultant DataTable from a StoredProc
        /// </summary>
        /// <param name="spName">Name of the StoredProc</param>
        /// <param name="parameters">Parameter List</param>
        /// <returns>Datatable as Result to the StoredProc</returns>
        public DataTable GetDataTable(string spName, params SqlParameter[] parameters)
        {
            return this.GetDataTable(spName, true, parameters);
        }

        /// <summary>
        /// Runs the SQL and Returns the Resultant DataTable
        /// </summary>
        /// <param name="sql">Normal SQL or Name of a Stored Proc</param>
        /// <param name="isStoredProc">If it is a StoredProc</param>
        /// <param name="parameters">Parameter List</param>
        /// <returns>Result DataTable</returns>
        public DataTable GetDataTable(string sql, bool isStoredProc, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                return this.GetDataTable(cmd, isStoredProc, parameters);
            }
        }

        /// <summary>
        /// Returns DataTable Result from a Command
        /// </summary>
        /// <param name="cmd">Command Object</param>
        /// <param name="isStoredProc">If it is a Stored Proc</param>
        /// <param name="parameters">Parameter List</param>
        /// <returns>DataTable Result</returns>
        public DataTable GetDataTable(SqlCommand cmd, bool isStoredProc, params SqlParameter[] parameters)
        {
            this.ConnectDB();
            DataTable dt = null;
            try
            {
                cmd = this.GetCommandWithParams(cmd, isStoredProc, parameters);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                dt = dt ?? new DataTable();
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                this.DisconnectDB();
            }
            return dt;
        }

        #endregion

        #region FillDataSet Functions

        /// <summary>
        /// Fills DataSet passed in
        /// </summary>
        /// <param name="sql">valid SQL name</param>
        /// <param name="ds">Resultant DataSet</param>
        public void FillDataSet(string sql, DataSet ds)
        {
            this.FillDataSet(sql, false, ds);
        }

        /// <summary>
        /// Runs a Stored Proc and gets the Result to the Dataset passed
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="ds"></param>
        /// <param name="parameters"></param>
        public void FillDataSet(string spName, DataSet ds, params  SqlParameter[] parameters)
        {
            this.FillDataSet(spName, true, ds, parameters);
        }
        /// <summary>
        /// Fills DataSet passed in.
        /// </summary>
        /// <param name="sql">Runs the SQL or Stored Proc Name</param>
        /// <param name="isStoredProc">If the SQL is a Stored Proc</param>
        /// <param name="ds">DataSet Passed in</param>
        /// <param name="parameters">Parameters</param>
        public void FillDataSet(string sql, bool isStoredProc, DataSet ds, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                this.FillDataSet(cmd, isStoredProc, ds, parameters);
            }
        }

        /// <summary>
        /// Fills a Dataset with Command
        /// </summary>
        /// <param name="cmd">Command Object Passed in</param>
        /// <param name="isStoredProc">If command is a stored Proc</param>
        /// <param name="ds">Dataset passed in</param>
        /// <param name="parameters">paremeters</param>
        public void FillDataSet(SqlCommand cmd, bool isStoredProc, DataSet ds, params SqlParameter[] parameters)
        {
            this.ConnectDB();
            try
            {
                cmd = this.GetCommandWithParams(cmd, isStoredProc, parameters);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                ds = ds ?? new DataSet();
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                this.DisconnectDB();
            }
        }

        #endregion

        #region FillDataTable Functions

        /// <summary>
        /// Fills the DataTable passed in
        /// </summary>
        /// <param name="sql">Valid SQL statement</param>
        /// <param name="dt">DataTable Object</param>
        public void FillDataTable(string sql, DataTable dt)
        {
            this.FillDataTable(sql, false, dt);
        }

        /// <summary>
        /// Fills the Datatable passed in
        /// </summary>
        /// <param name="spName">Stored Proc Name</param>
        /// <param name="dt">DataTable passed</param>
        /// <param name="parameters">Parameter list to be added with the Stored Proc</param>
        public void FillDataTable(string spName, DataTable dt, params  SqlParameter[] parameters)
        {
            this.FillDataTable(spName, true, dt, parameters);
        }

        /// <summary>
        /// Fills the Datatable passed in
        /// </summary>
        /// <param name="sql">Valid SQL statement or Stored Proc Name</param>
        /// <param name="isStoredProc">If it is a Stored Proc</param>
        /// <param name="dt">DataTable passed</param>
        /// <param name="parameters">Parameter list to be added with the Stored Proc</param>
        public void FillDataTable(string sql, bool isStoredProc, DataTable dt, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                this.FillDataTable(cmd, isStoredProc, dt, parameters);
            }
        }

        /// <summary>
        /// Fills the Datatable passed in
        /// </summary>
        /// <param name="cmd">Command Object to run</param>
        /// <param name="isStoredProc">If it is a Stored Proc</param>
        /// <param name="dt">DataTable passed</param>
        /// <param name="parameters">Parameter list to be added with the Stored Proc</param>
        public void FillDataTable(SqlCommand cmd, bool isStoredProc, DataTable dt, params SqlParameter[] parameters)
        {
            this.ConnectDB();
            try
            {
                cmd = this.GetCommandWithParams(cmd, isStoredProc, parameters);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                dt = dt ?? new DataTable();
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                this.DisconnectDB();
            }
        }

        #endregion

        #region ExecuteNonQuery Functions

        /// <summary>
        /// Executed the Statement directly in database.
        /// </summary>
        /// <param name="sql">Statement to Execute</param>
        /// <returns>Number of Rows Affected</returns>
        public int ExecuteNonQuery(string sql)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                return this.ExecuteNonQuery(cmd, false);
            }
        }

        /// <summary>
        /// Executed the Statement directly in database.
        /// </summary>
        /// <param name="spName">Stored Proc Name or sql statement</param>
        /// <param name="isStoredProc">If this is a Stored Proc</param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string spName, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(spName))
            {
                return this.ExecuteNonQuery(cmd, true, parameters);
            }
        }

        /// <summary>
        /// Executed the Statement directly in database.
        /// </summary>
        /// <param name="cmd">Command Object</param>
        /// <param name="isStoredProc">If this is a Stored Proc</param>
        /// <param name="parameters">Parameter List</param>
        /// <returns>Number of Rows Affected or Return value of Stored Proc</returns>
        public int ExecuteNonQuery(SqlCommand cmd, bool isStoredProc, params SqlParameter[] parameters)
        {
            this.ConnectDB();
            try
            {
                cmd = this.GetCommandWithParams(cmd, isStoredProc, parameters);
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                this.DisconnectDB();
            }
        }

        #endregion

        #region ExecuteScalar Functions

        public object ExecuteScalar(string sql)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                return this.ExecuteScalar(cmd, false);
            }
        }

        public object ExecuteScalar(string spName, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(spName))
            {
                return this.ExecuteScalar(cmd, true, parameters);
            }
        }

        public object ExecuteScalar(SqlCommand cmd, bool isStoredProc, params SqlParameter[] parameters)
        {
            this.ConnectDB();
            object obj = null;
            try
            {
                cmd = this.GetCommandWithParams(cmd, isStoredProc, parameters);
                obj = cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                this.DisconnectDB();
            }
            return obj;
        }

        #endregion

        # region ExecuteList Functions

        /// <summary>
        /// Runs the qurey and returns the list of data selected in 1st column
        /// </summary>
        /// <param name="sql">Sql statement</param>
        /// <returns>List of string</returns>
        public IList<string> ExecuteList(string sql)
        {
            return this.ExecuteList(sql, null);
        }

        /// <summary>
        /// Runs the qurey and returns the list of data selected in 1st column
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IList<string> ExecuteList(string sql, params SqlParameter[] parameters)
        {
            return this.ExecuteList(sql, 0, false, parameters);
        }

        /// <summary>
        /// Runs the qurey and returns the list of data selected in 1st column
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="isStoredProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IList<string> ExecuteList(string sql, bool isStoredProc, params SqlParameter[] parameters)
        {
            return this.ExecuteList(sql, 0, isStoredProc, parameters);
        }

        /// <summary>
        /// Runs the qurey and returns the list of data selected in 1st column
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="columnIndex">Index value to be selected in List</param>
        /// <param name="isStoredProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IList<string> ExecuteList(string sql, int columnIndex, bool isStoredProc, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                DataTable dt = this.GetDataTable(cmd, isStoredProc, parameters);
                IList<string> list = new List<string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                    list.Add(dt.Rows[i][columnIndex].ToString());
                return list;
            }
        }

        /// <summary>
        /// Runs the qurey and returns the list of data selected in 1st column
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="selectionColumn">Name of the Column to be selected</param>
        /// <param name="isStoredProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IList<string> ExecuteList(string sql, string selectionColumn, bool isStoredProc, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                DataTable dt = this.GetDataTable(cmd, isStoredProc, parameters);
                IList<string> list = new List<string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                    list.Add(dt.Rows[i][selectionColumn].ToString());
                return list;
            }
        }
        # endregion

        # region ExecuteDictionary Functions

        /// <summary>
        /// Runs the query and returns the list of data selected
        /// </summary>
        /// <param name="sql">Sql statement</param>
        /// <returns>Hash of string</returns>
        public IDictionary<string, string> ExecuteDictionary(string sql)
        {
            return this.ExecuteDictionary(sql, null);
        }

        /// <summary>
        /// Runs the query and returns the list of data selected
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IDictionary<string, string> ExecuteDictionary(string sql, params SqlParameter[] parameters)
        {
            return this.ExecuteDictionary(sql, 0, 1, false, parameters);
        }

        /// <summary>
        /// Runs the query and returns the list of data selected
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="isStoredProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IDictionary<string, string> ExecuteDictionary(string sql, bool isStoredProc, params SqlParameter[] parameters)
        {
            return this.ExecuteDictionary(sql, 0, 1, isStoredProc, parameters);
        }

        /// <summary>
        /// Runs the query and returns the list of data selected
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="columnIndex">Index value to be selected in Dictionary</param>
        /// <param name="columnValue">Value to be selected in Dictionary</param>
        /// <param name="isStoredProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IDictionary<string, string> ExecuteDictionary(string sql, int columnIndex, int columnValue, bool isStoredProc, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                DataTable dt = this.GetDataTable(cmd, isStoredProc, parameters);
                IDictionary<string, string> dict = new Dictionary<string, string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                    dict.Add(dt.Rows[i][columnIndex].ToString(), dt.Rows[i][columnValue].ToString());
                return dict;
            }
        }

        /// <summary>
        /// Runs the qurey and returns the list of data selected in 1st column
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="selectionColumn">Name of the Column to be selected as Index</param>
        /// <param name="selectionValue">Name of the Column to be selected as Value</param>
        /// <param name="isStoredProc"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public IDictionary<string, string> ExecuteDictionary(string sql, string selectionColumn, string selectionValue, bool isStoredProc, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(sql))
            {
                DataTable dt = this.GetDataTable(cmd, isStoredProc, parameters);
                IDictionary<string, string> dict = new Dictionary<string, string>();
                for (int i = 0; i < dt.Rows.Count; i++)
                    dict.Add(dt.Rows[i][selectionColumn].ToString(), dt.Rows[i][selectionValue].ToString());
                return dict;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbfactory"></param>
        /// <param name="ddl"></param>
        /// <param name="SpName"></param>
        /// <param name="param"></param>
        public static void LoadDDL(SqlDataFactory dbfactory, DropDownList ddl, string SpName, SqlParameter[] param)
        {
            DataTable dt = dbfactory.GetDataTable(SpName, param);

            if (dt != null && dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "FieldName"; // Specify Actual Fieldname 
                ddl.DataBind();
            }
        }

        # endregion

        #region Internal Function

        internal SqlCommand GetCommandWithParams(SqlCommand cmd, bool isStoredProc, params SqlParameter[] parameters)
        {
            cmd.Connection = this.Connection;
            cmd.CommandTimeout = this.CommandTimeOut;
            cmd.CommandType = (isStoredProc) ? CommandType.StoredProcedure : CommandType.Text;

            if (this.IsInTransaction && cmd.Transaction == null)
                cmd.Transaction = this.Transaction;

            if (parameters != null && parameters.Length > 0)
                this.AttachParameters(cmd, parameters);
            return cmd;
        }

        internal void AttachParameters(SqlCommand cmd, params SqlParameter[] parameters)
        {
            if (parameters != null)
            {
                cmd.Parameters.Clear();
                foreach (SqlParameter p in parameters)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput || p.Direction == ParameterDirection.Input) &&
                            p.Value == null)
                            p.Value = DBNull.Value;
                        cmd.Parameters.Add(p);
                    }
                }
            }
        }

        #endregion

        #region Create Parameter Functions

        public SqlParameter CreateReturnValueParameter(string name, SqlDbType type)
        {
            SqlParameter parameter = new SqlParameter(name, type);
            parameter.Direction = ParameterDirection.ReturnValue;
            return parameter;
        }

        public SqlParameter CreateOutputParameter(string name, SqlDbType type)
        {

            SqlParameter parameter = new SqlParameter(name, type);
            parameter.Direction = ParameterDirection.InputOutput;
            return parameter;
        }

        public SqlParameter CreateOutputParameter(string name, SqlDbType type, byte size)
        {
            SqlParameter parameter = new SqlParameter(name, type, size);
            parameter.Direction = ParameterDirection.InputOutput;
            return parameter;
        }

        public SqlParameter CreateOutputParameter(string name, SqlDbType type, byte precision, byte scale)
        {
            SqlParameter parameter = new SqlParameter(name, type);
            parameter.Direction = ParameterDirection.InputOutput;
            parameter.Precision = precision;
            parameter.Scale = scale;
            return parameter;
        }

        public SqlParameter CreateParameter(string name, object value, SqlDbType type)
        {

            SqlParameter parameter = new SqlParameter(name, value);
            parameter.SqlDbType = type;
            parameter.Direction = ParameterDirection.Input;
            return parameter;
        }

        public SqlParameter CreateParameter(string name, object value, SqlDbType type, byte size)
        {

            SqlParameter parameter = new SqlParameter(name, type, size);
            parameter.Direction = ParameterDirection.Input;
            parameter.Value = value;
            return parameter;
        }

        public SqlParameter CreateParameter(string name, object value, SqlDbType type, byte precision, byte scale)
        {

            SqlParameter parameter = new SqlParameter(name, type);
            parameter.Direction = ParameterDirection.Input;
            parameter.Value = value;
            parameter.Precision = precision;
            parameter.Scale = scale;
            return parameter;
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            if (this._connection != null)
                this._connection.Dispose();
        }
        public virtual void Dispose(bool isDisposeComponent)
        {
            if (!isDisposeComponent)
                this.Dispose();
        }

        #endregion
    }
}