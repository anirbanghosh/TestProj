﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;


namespace DycomSafteyViewDAL
{
   public class BasePage:System.Web.UI.Page
    {
       public SqlDataFactory _dbfact;
        public string ConnectString
        {
            get
            {
                //return ConfigurationManager.ConnectionStrings["condb"].ConnectionString;
                return System.Configuration.ConfigurationManager.ConnectionStrings["condb"].ConnectionString;
            }
        }

        public SqlDataFactory DbFactory
        {
            get
            {
                if (_dbfact == null)
                    _dbfact = new SqlDataFactory(this.ConnectString);
                return _dbfact;
            }

        }
    }
}
