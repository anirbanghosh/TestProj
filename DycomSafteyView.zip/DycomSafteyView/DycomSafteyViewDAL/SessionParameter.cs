﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;




namespace DycomSafteyViewDAL
{
    public class SessionParameter:BasePage
    {
        SqlDataFactory objSqlDataFactory = new SqlDataFactory();
        public void ConnectDB()
        {
            objSqlDataFactory.ConnectDB();
        }
        public void DisconnectDB()
        {
            objSqlDataFactory.DisconnectDB();
        }
        public DataTable GetIntelexIncidentBKId()
        {
            return objSqlDataFactory.GetDataTableBySQL("Select distinct IntelexIncidentBKId from dim.DimensionIntelexIncident order by IntelexIncidentBKId");
        }

        public DataTable GetAbbreviatedCompanyName()
        {
            return objSqlDataFactory.GetDataTableBySQL("Select distinct AbbreviatedCompanyName from dbo.FactClaim where rtrim(ltrim(len(AbbreviatedCompanyName))) > 0 order by AbbreviatedCompanyName");
        }

        public DataTable GetIntelexOfficeLocationName()
        {
            return objSqlDataFactory.GetDataTableBySQL("Select distinct IntelexOfficeLocationName from dbo.DimensionIntelexIncident order by IntelexOfficeLocationName");
        }

        public DataTable GetIntelexClaimStatusCode()
        {
            return objSqlDataFactory.GetDataTableBySQL("Select distinct IntelexClaimStatusCode from DimensionClaim order by IntelexClaimStatusCode");
        }

        public DataTable GetIntelexReportedtoCarrierDate()
        {
            return objSqlDataFactory.GetDataTableBySQL("Select distinct IntelexReportedtoCarrierDate from DimensionClaim order by IntelexReportedtoCarrierDate");
        }
       
        /*Section : Pushing Data to the Application Session Database, Created On = 10/05/2012, Author= Anirban Ghosh */

        /* Pushing Data to Session & other Tables */
        public void PushDataToSession(String SessionDetails)
        {
       
            string[] paramSession = SessionDetails.Split("~".ToCharArray());
            
            using (var connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["conApplicationSession"].ConnectionString))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        using (var cmndSession = new SqlCommand("INSERT INTO Session (SessionName,LastUpdateUserId,LastUpdateTimestamp) VALUES ('" + paramSession[14] + "','corp\tc0046','" +DateTime.Today.ToString() +"')", connection, transaction))
                        {
                            cmndSession.ExecuteNonQuery();
                        }

                        using (var cmndSessionParameter = new SqlCommand("INSERT INTO SessionParameter(ParameterId,ParameterValue,SequenceNumber,LastUpdateUserId,LastUpdateTimestamp) VALUES (<SessionId, bigint,>,<ParameterId, bigint,>,<ParameterValue, nvarchar(1000),>,<SequenceNumber, int,>,<LastUpdateUserId, varchar(30),>,<LastUpdateTimestamp, datetime2(7),>)", connection, transaction))
                        {
                            cmndSessionParameter.ExecuteNonQuery();
                        }
                        using (var cmndSessionReference = new SqlCommand("INSERT INTO SessionReference(SessionId,ReferenceId,DataSourceId,LastUpdateUserId,LastUpdateTimestamp)VALUES(<SessionId, bigint,>,<ReferenceId, bigint,>,<DataSourceId, bigint,>,<LastUpdateUserId, varchar(30),>,<LastUpdateTimestamp, datetime2(7),>)", connection, transaction))
                        {
                            cmndSessionReference.ExecuteNonQuery();
                        }
                        using (var cmndSessionSortCriteria = new SqlCommand("INSERT INTO SessionSortCriteria(SessionId,SortColumnId,SequenceNumber,SortDirectionText,QueryText,LastUpdateUserId,LastUpdateTimestamp) VALUES(<SessionId, bigint,>,<SortColumnId, bigint,>,<SequenceNumber, int,>,<SortDirectionText, varchar(20),>,<QueryText, varchar(2000),>,<LastUpdateUserId, varchar(30),>,<LastUpdateTimestamp, datetime2(7),>)", connection, transaction))
                        {
                            cmndSessionSortCriteria.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
    }
}
