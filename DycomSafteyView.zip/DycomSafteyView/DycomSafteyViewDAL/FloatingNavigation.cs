﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DycomSafteyViewDAL
{
    public class FloatingNavigation
    {
        SqlDataFactory objSqlDataFactory = new SqlDataFactory();
        public void ConnectDB()
        {
            objSqlDataFactory.ConnectDB();
        }
        public void DisconnectDB()
        {
            objSqlDataFactory.DisconnectDB();
        }

        public DataSet GetFloatingNavigationDetailsByIncidents(string incidents)
        {
            return objSqlDataFactory.GetDataSet("select distinct dc.IntelexRecordBKId,dc.claimnumber from DimensionClaim dc inner join  DimensionIntelexIncident DII on dc.IntelexRecordBKId = DII.intelexincidentBKid and dc.IntelexRecordBKId in(" + incidents + ")");
        }
    }
}
