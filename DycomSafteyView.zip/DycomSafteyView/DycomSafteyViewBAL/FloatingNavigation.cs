﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using DycomSafteyViewDAL;

namespace DycomSafteyViewBAL
{
    public class FloatingNavigation
    {
        #region Properties

        public string IncidentID
        {
            get;
            set;
        }
        public string GenaralLiability
        {
            get;
            set;
        }
        public string WorkerCopy1
        {
            get;
            set;
        }
        public string WorkerCopy2
        {
            get;
            set;
        }
        
        #endregion

        #region Methods

        DycomSafteyViewDAL.FloatingNavigation objFloatingNavigationDAL = new DycomSafteyViewDAL.FloatingNavigation();
        public void ConnectDB()
        {
            objFloatingNavigationDAL.ConnectDB();
        }
        public void DisconnectDB()
        {
            objFloatingNavigationDAL.DisconnectDB();
        }

        public DataSet GetFloatingNavigationDetailsByIncidents(string incidents)
        {
            return objFloatingNavigationDAL.GetFloatingNavigationDetailsByIncidents(incidents);
        }
        public static string[] GetParamSession(string paramSession)
        {
            return (paramSession.Split("~".ToCharArray()));
        }
        #endregion
    }
}
