﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DycomSafteyViewDAL;

namespace DycomSafteyViewBAL
{
    public class SessionParameter
    {
        DycomSafteyViewDAL.SessionParameter objSessionParameterDAL = new DycomSafteyViewDAL.SessionParameter();
        public void ConnectDB()
        {
            objSessionParameterDAL.ConnectDB();
        }
        public void DisconnectDB()
        {
            objSessionParameterDAL.DisconnectDB();
        }
        public DataTable GetIntelexIncidentBKId()
        {
            return objSessionParameterDAL.GetIntelexIncidentBKId();
        }

        public DataTable GetAbbreviatedCompanyName()
        {
            return objSessionParameterDAL.GetAbbreviatedCompanyName();
        }

        public DataTable GetIntelexOfficeLocationName()
        {
            return objSessionParameterDAL.GetIntelexOfficeLocationName();
        }

        public DataTable GetIntelexClaimStatusCode()
        {
            return objSessionParameterDAL.GetIntelexClaimStatusCode();
        }

        public DataTable GetIntelexReportedtoCarrierDate()
        {
            return objSessionParameterDAL.GetIntelexReportedtoCarrierDate();
        }
        /* Date = 10.05.2012, Author ="Anirban Ghosh" */
        /* Objective: Saving  Data parameters to the Application Session Database */
        /* Short Description : This AddSessionData Function will Add the Data to the Following Cmma Separated Tables Through DAL" */
        /* [dbo].[Session] [dbo].[SessionParameter] [dbo].[SessionReference] [dbo].[SessionSortCriteria]*/
        /* Master Tables :  [dbo].[Application] [dbo].[ApplicationParameter] [dbo].[DataSource] [dbo].[DataSource]  [dbo].[Parameter] */

        public Boolean AddSessionData(string ParamList)
        {
            /* Calling Function for Adding Data to the [dbo].[Session] */
            /* Calling Function for Adding Data to the [dbo].[SessionParameter] */
            /* Calling Function for Adding Data to the [dbo].[SessionReference] */
            /* Calling Function for Adding Data to the [dbo].[SessionSortCriteria] */

            Boolean RetVal;
            return RetVal ;
        }
    }
}
