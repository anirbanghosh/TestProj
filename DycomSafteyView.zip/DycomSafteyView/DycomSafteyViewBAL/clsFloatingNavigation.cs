﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DycomSafteyViewBAL
{
    public class clsFloatingNavigation
    {
        public string StDate { get; set; }
        public string EDate { get; set; }
        public string IncidentID
        {
            get;
            set;
        }
        public string GenaralLiability
        {
            get;
            set;
        }
        public string WorkerCopy1
        {
            get;
            set;
        }
        public string WorkerCopy2
        {
            get;
            set;
        }
    }
}
