﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DycomSafteyViewBAL
{
    public class DimensionIntelexIncident
    {
        public string IntelexIncidentbkid
        {
            get;
            set;
        }
        public string IntelexIncidentTypeText
        {
            get;
            set;
        }
    }
}
