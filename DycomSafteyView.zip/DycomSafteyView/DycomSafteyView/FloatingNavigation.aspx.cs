﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Web.Services;


public partial class FloatingNavigation : System.Web.UI.Page
{
    public string IncidentsCollection = string.Empty;
    public string StartDate = string.Empty;
    public string EndDate = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            IncidentsCollection = Session["IncidentsCollection"].ToString();
            StartDate = Session["StartDate"].ToString();
            EndDate = Session["EndDate"].ToString();
            
                        
        }
    }
    /// <summary>
    /// Web Method BindFloatingNavigation that returns incidents details.
    /// </summary>
    /// <returns></returns>
    [WebMethod(EnableSession=true)]
    public static List<DycomSafteyViewBAL.clsFloatingNavigation> BindFloatingNavigation()
    {
        DycomSafteyViewBAL.FloatingNavigation objFloatingNavigationBAL = new DycomSafteyViewBAL.FloatingNavigation();
        List<DycomSafteyViewBAL.clsFloatingNavigation> lstFloatingNavigation = new List<DycomSafteyViewBAL.clsFloatingNavigation>();
        DataSet dsFloatingNavigation = new DataSet();
        dsFloatingNavigation = objFloatingNavigationBAL.GetFloatingNavigationDetailsByIncidents(HttpContext.Current.Session["IncidentsCollection"].ToString());
        DataTable dt = new DataTable();
        dt = dsFloatingNavigation.Tables[0];
        foreach (DataRow dtrow in dsFloatingNavigation.Tables[0].Rows)
        {
            DycomSafteyViewBAL.clsFloatingNavigation flNavigation = new DycomSafteyViewBAL.clsFloatingNavigation();
            flNavigation.StDate = HttpContext.Current.Session["StartDate"].ToString();
            flNavigation.EDate = HttpContext.Current.Session["EndDate"].ToString();
            flNavigation.IncidentID = dtrow["IntelexRecordBKId"].ToString();
            flNavigation.GenaralLiability = dtrow["claimnumber"].ToString();
            flNavigation.WorkerCopy1 = dtrow["claimnumber"].ToString();
            flNavigation.WorkerCopy2 = dtrow["claimnumber"].ToString();
            lstFloatingNavigation.Add(flNavigation);
        }
        return lstFloatingNavigation.ToList();
    }
    
}
