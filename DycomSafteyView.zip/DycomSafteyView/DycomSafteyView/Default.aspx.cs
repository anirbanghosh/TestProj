﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace DycomSafteyView
{
    public partial class Default : System.Web.UI.Page
    {
        DycomSafteyViewBAL.SessionParameter objSessionParameterBAL = new DycomSafteyViewBAL.SessionParameter();
        string IncidentsCollection = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                objSessionParameterBAL.ConnectDB();
                DataTable dtIncidentID = objSessionParameterBAL.GetIntelexIncidentBKId();
                lstIntelexIncidentID.DataSource = dtIncidentID;
                lstIntelexIncidentID.DataTextField = "IntelexIncidentBKId";
                lstIntelexIncidentID.DataValueField = "IntelexIncidentBKId";
                lstIntelexIncidentID.DataBind();

                DataTable dtSubsidiary = objSessionParameterBAL.GetAbbreviatedCompanyName();
                ddlSubsidiary.DataSource = dtSubsidiary;
                ddlSubsidiary.DataValueField = "AbbreviatedCompanyName";
                ddlSubsidiary.DataTextField = "AbbreviatedCompanyName";
                ddlSubsidiary.DataBind();


                DataTable dtCompanyLocation = objSessionParameterBAL.GetIntelexOfficeLocationName();
                ddlCompanyLocation.DataSource = dtCompanyLocation;
                ddlCompanyLocation.DataValueField = "IntelexOfficeLocationName";
                ddlCompanyLocation.DataTextField = "IntelexOfficeLocationName";
                ddlCompanyLocation.DataBind();

                DataTable dtClaimStatus = objSessionParameterBAL.GetIntelexClaimStatusCode();
                ddlClaimStatus.DataSource = dtClaimStatus;
                ddlClaimStatus.DataValueField = "IntelexClaimStatusCode";
                ddlClaimStatus.DataTextField = "IntelexClaimStatusCode";
                ddlClaimStatus.DataBind();

                DataTable dtReportedtoCarrier = objSessionParameterBAL.GetIntelexReportedtoCarrierDate();
                ddlReportedtoCarrier.DataSource = dtReportedtoCarrier;
                ddlReportedtoCarrier.DataValueField = "IntelexReportedtoCarrierDate";
                ddlReportedtoCarrier.DataTextField = "IntelexReportedtoCarrierDate";
                ddlReportedtoCarrier.DataBind();

                objSessionParameterBAL.DisconnectDB();


                Guid guidsessionid;
                guidsessionid = Guid.NewGuid();
                SessionID.Value = guidsessionid.ToString();
            }
        }
        protected void btnGettingStarted_Click(object sender, EventArgs e)
        {
            
            foreach (ListItem item in lstIntelexIncidentID.Items)
            {
                if (item.Selected == true)
                {
                    IncidentsCollection += item.Value.ToString() + ",";
                }
            }
            if (!string.IsNullOrEmpty(IncidentsCollection))
            {
                IncidentsCollection = IncidentsCollection.Substring(0, IncidentsCollection.Length - 1);
                Session["IncidentsCollection"] = IncidentsCollection;
                Session["StartDate"] = datum1.Value.Trim();
                Session["EndDate"] = datum2.Value.Trim();


            }
            Response.Redirect("FloatingNavigation.aspx");
        }

        protected void btnSaveSession_Click(object sender, EventArgs e)
        {
            /* Creation of Parameter */
            string ParamValues = IncidentsCollection + "~" + ddlSubsidiary.SelectedValue + "~" + ddlCompanyLocation.SelectedValue + "~" +
                    ddlClaimStatus.SelectedValue + "~" + ddlEmployee.SelectedValue + "~" + ddlIncidentsSafetyFlagSet.SelectedValue + "~" +
                    ddlIncludesopenClaims.SelectedValue + "~" + ddlReportedtoCarrier.SelectedValue + "~" + datum1.Value.Trim() + "~" +
                    datum2.Value.Trim() + "~" + datum3.Value.Trim() + "~" + datum4.Value.Trim() + "~" + datum5.Value.Trim() + "~" +
                    datum6.Value.Trim()+"~"+ SessionName.Value;
            
                    objSessionParameterBAL.AddSessionData(ParamValues);
        }



    

       
    }
}